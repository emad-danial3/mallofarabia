<?php

namespace App\Http\Repositories;

interface NotificationRepository
{

}
