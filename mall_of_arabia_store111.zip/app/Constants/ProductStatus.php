<?php

namespace App\Constants;

class ProductStatus
{
    const   IN_STOCK              = 'in stock';
    const   OUT_STOCK              = 'out stock';
}
