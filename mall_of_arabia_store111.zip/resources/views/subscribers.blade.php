@extends('layouts.app')
@section('content')
    @include('layoutsWep.componants.subscriber')
@endsection
