
<html>
<head>
    <title>Reset password</title>
</head>
<body>





<p>For Resetting Your Password Please Follow <a href='http://nettinghub.com/rest/forgot/{{$data['id']}}'>This Link</a>  </p>

</body>
</html>
