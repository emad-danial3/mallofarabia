
<html>
<head>
    <title>Reset password</title>
</head>
<body>

<h3>For Resetting Your Password Your Code :  {{$data['code']}}</h3>

</body>
</html>
