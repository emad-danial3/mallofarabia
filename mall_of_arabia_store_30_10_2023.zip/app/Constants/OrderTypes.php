<?php

namespace App\Constants;

class OrderTypes
{
    const   CREATE_USER = 'create_user';
    const   SINGLE = 'single';
    const   FREE_ACCOUNT = 'free_account';
}
