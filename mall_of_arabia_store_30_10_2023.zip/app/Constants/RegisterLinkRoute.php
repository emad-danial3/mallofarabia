<?php

namespace App\Constants;

class  RegisterLinkRoute
{
    const   FreeLink    = 'singUpFree';
    const   PRIMUMLink  = 'singUpPremium';
}
