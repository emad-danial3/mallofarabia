<?php

namespace App\Constants;

class OrderStatus
{
    const   PAID = 'PAID';
    const   PENDING  = 'PENDING';
    const   EXPIRED  = 'EXPIRED';
    const   DELETED  = 'DELETED';

}
