<?php

namespace App\ValidationClasses\Admin;

class UserValidation
{

}
