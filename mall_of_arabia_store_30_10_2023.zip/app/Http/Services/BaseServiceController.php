<?php

namespace App\Http\Services;

use App\Http\Controllers\Controller;

class BaseServiceController  extends  Controller
{

}
