{{--@extends('layouts.app')--}}
{{--@section('style')--}}
{{--    <style>--}}
{{--       .title h2{--}}
{{--          color:rgba(25, 151, 183, 1);--}}
{{--       }--}}
{{--        .blog-section .blog-box{--}}
{{--           border-radius: 30px;--}}
{{--       }--}}
{{--        .blog-section .blog-box .blog-box-image{--}}
{{--           border-radius: 30px;--}}
{{--       }--}}
{{--     .ratio_45{--}}
{{--       box-shadow: 0px 2px 4px rgba(0, 0, 0, 0.15);--}}
{{--border-radius: 16px;--}}
{{--       }--}}

{{--     .slick-dots{--}}
{{--         display: none;--}}
{{--     }--}}
{{--     .top-image{--}}
{{--         max-height: 280px;--}}
{{--     }--}}
{{--    </style>--}}
{{--@endsection--}}
{{--@section('content')--}}


{{--    <!-- Home Section Start -->--}}
{{--    <section class="home-section-2 home-section-bg pt-0 overflow-hidden">--}}
{{--        <div class="container-fluid p-0">--}}
{{--            <div class="row">--}}
{{--                <div class="col-12">--}}
{{--                    <div class="slider-animate">--}}
{{--                        <div>--}}
{{--                            <div class="home-contain rounded-0 p-0 background-size-cover" >--}}
{{--                                <img src="../assets/images/images/woman.png"--}}
{{--                                     class="img-fluid bg-img blur-up lazyload" alt="">--}}
{{--                                <div class="home-detail home-big-space p-center-left home-overlay position-relative">--}}
{{--                                    <div class="container-fluid-lg">--}}
{{--                                        <div>--}}

{{--                                            <h1 class="heding-2 text-white">TESTIMONIALS</h1>--}}
{{--                                            <h3 class="content-2 text-white w-50"> if you have free time you can build your business by yourself and from home without any boss so the customer has the flexibility to work at any time.</h3>--}}

{{--                                        </div>--}}
{{--                                    </div>--}}
{{--                                </div>--}}
{{--                            </div>--}}
{{--                        </div>--}}
{{--                    </div>--}}
{{--                </div>--}}
{{--            </div>--}}
{{--        </div>--}}
{{--    </section>--}}
{{--    <!-- Home Section End -->--}}



{{--    <!-- Blog Section Start -->--}}
{{--    <section class="blog-section">--}}
{{--        <div class="container-fluid-lg text-center">--}}

{{--            <div class="slider-4-blog arrow-slider slick-height insider-bottom-section" >--}}
{{--                <div class="p-2">--}}
{{--                    <div class="blog-box ratio_45">--}}
{{--                        <div class="blog-box-image">--}}
{{--                            <a href="/">--}}
{{--                                <img src="../assets/images/images/1472.jpg" class="blur-up lazyload w-100 top-image" alt="">--}}
{{--                            </a>--}}
{{--                        </div>--}}

{{--                        <div class="blog-detail">--}}

{{--                            <a href="/">--}}
{{--                                <h3 class="theme-second-color">Seeking Opportunity</h3>--}}

{{--                            </a>--}}

{{--                        </div>--}}
{{--                    </div>--}}
{{--                </div>--}}

{{--                <div class="p-2">--}}
{{--                    <div class="blog-box ratio_45">--}}
{{--                        <div class="blog-box-image">--}}
{{--                            <a href="/common_questions">--}}
{{--                                <img src="../assets/images/images/9635.jpg" class="blur-up lazyload w-100 top-image" alt="">--}}
{{--                            </a>--}}
{{--                        </div>--}}

{{--                        <div class="blog-detail">--}}

{{--                          <a href="/">--}}
{{--                                <h3 class="theme-second-color">Seeking Opportunity</h3>--}}

{{--                            </a>--}}

{{--                        </div>--}}
{{--                    </div>--}}
{{--                </div>--}}

{{--                <div class="p-2">--}}
{{--                    <div class="blog-box ratio_45">--}}
{{--                        <div class="blog-box-image">--}}
{{--                            <a href="/fast_facts">--}}
{{--                                <img src="../assets/images/images/998785.jpeg" class="blur-up lazyload w-100 top-image" alt="">--}}
{{--                            </a>--}}
{{--                        </div>--}}

{{--                        <div class="blog-detail">--}}

{{--                           <a href="/">--}}
{{--                                <h3 class="theme-second-color">Seeking Opportunity</h3>--}}

{{--                            </a>--}}

{{--                        </div>--}}
{{--                    </div>--}}
{{--                </div>--}}
{{--            </div>--}}
{{--        </div>--}}
{{--    </section>--}}

{{--    <!-- Blog Section Start -->--}}
{{--    <section class="blog-section">--}}
{{--        <div class="container-fluid-lg text-center">--}}
{{--            <h3 class="text-secondary">Extra income, flexibility, achievement – the reasons why many Independent Business Owners start a 4UNettingHub business.</h3>--}}
{{--        </div>--}}
{{--    </section>--}}
{{--    <!-- Blog Section End -->--}}

{{--<!-- Team Section Start -->--}}
{{--<section class="team-section section-lg-space ">--}}
{{--    <div class="container-fluid-lg ">--}}
{{--        <div class="row">--}}


{{--            <div class="col-12">--}}
{{--                <h2 class=" theme-second-color mb-2">Seeking Opportunity </h2>--}}
{{--            </div>--}}
{{--            <div class="col-6" style="color: #979797">--}}

{{--                <div class="title text-left">--}}


{{--                    <p class="w-75 lh-base">--}}

{{--                       >>>>>>>--}}

{{--                    </p>--}}


{{--<br>--}}

{{--                </div>--}}

{{--            </div>--}}

{{--              <div class="col-6">--}}
{{--<video width="400" height="400" controls>--}}
{{--      <source src="/images/video/MinuteTimer.mp4" type="video/mp4">--}}
{{--    Your browser does not support the video tag.--}}
{{--</video>--}}

{{--            </div>--}}
{{--        </div>--}}
{{--    </div>--}}
{{--</section>--}}
{{--<!-- Team Section End -->--}}









{{--    <!-- Blog Section Start -->--}}
{{--    <section class="blog-section">--}}
{{--        <div class="container-fluid-lg text-center">--}}
{{--            <div class="title text-center">--}}
{{--                <h2 class="my-3 ">{{trans('website.4U Netting Hub Insider',[],session()->get('locale'))}}</h2>--}}
{{--                            <h4 class="text-center fw-300 w-75 mx-auto lh-base">--}}
{{--                                {{trans('website.Read news, stories, answers to questions',[],session()->get('locale'))}}--}}
{{--                            </h4>--}}
{{--            </div>--}}

{{--            <div class="slider-4-blog arrow-slider slick-height insider-bottom-section" >--}}
{{--                <div class="p-2">--}}
{{--                    <div class="blog-box ratio_45">--}}
{{--                        <div class="blog-box-image">--}}
{{--                            <a href="/testimonials">--}}
{{--                                <img src="../assets/images/images/fruit.png" class="blur-up lazyload w-100" alt="">--}}
{{--                            </a>--}}
{{--                        </div>--}}

{{--                        <div class="blog-detail">--}}

{{--                            <a href="/testimonials">--}}
{{--                                <h3>4U Netting Hub STORIES</h3>--}}
{{--                            </a>--}}

{{--                        </div>--}}
{{--                    </div>--}}
{{--                </div>--}}

{{--                <div class="p-2">--}}
{{--                    <div class="blog-box ratio_45">--}}
{{--                        <div class="blog-box-image">--}}
{{--                            <a href="/common_questions">--}}
{{--                                <img src="../assets/images/images/blog image.png" class="blur-up lazyload w-100" alt="">--}}
{{--                            </a>--}}
{{--                        </div>--}}

{{--                        <div class="blog-detail">--}}

{{--                            <a href="/common_questions">--}}
{{--                                <h3>{{trans('website.COMMON QUESTIONS',[],session()->get('locale'))}}</h3>--}}
{{--                            </a>--}}

{{--                        </div>--}}
{{--                    </div>--}}
{{--                </div>--}}

{{--                <div class="p-2">--}}
{{--                    <div class="blog-box ratio_45">--}}
{{--                        <div class="blog-box-image">--}}
{{--                            <a href="/fast_facts">--}}
{{--                                <img src="../assets/images/images/Rectangle 12391.png" class="blur-up lazyload w-100" alt="">--}}
{{--                            </a>--}}
{{--                        </div>--}}

{{--                        <div class="blog-detail">--}}

{{--                            <a href="/fast_facts">--}}
{{--                                <h3>{{trans('website.FAST FACTS',[],session()->get('locale'))}}</h3>--}}
{{--                            </a>--}}

{{--                        </div>--}}
{{--                    </div>--}}
{{--                </div>--}}
{{--            </div>--}}
{{--        </div>--}}
{{--    </section>--}}
{{--    <!-- Blog Section End -->--}}


{{--    <!-- Team Section Start -->--}}
{{--    <section class=" text-center p-0 mt-4  homecategories">--}}
{{--        <div class="container-fluid text-center">--}}
{{--            <div class="row pt-4 pb-4">--}}
{{--                <div class="col-12">--}}
{{--                    @include('layoutsWep.componants.buttomcontact')--}}
{{--                </div>--}}
{{--            </div>--}}
{{--        </div>--}}
{{--    </section>--}}
{{--    <!-- Team Section End -->--}}

{{--@endsection--}}
