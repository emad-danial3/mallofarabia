<html>
<head>
</head>
<body>

<img  src='http://nettinghub.com/logo2.png' alt='nettinghub'>

<h3 style='color:rgb(0, 148, 167)'>Hello Netting Hub New Member,</h3>

<p style='color:rgb(0, 148, 167)'>Thanks for choosing to be part of Netting Hub team! We are all working towards a common goal and your
    contribution is integral. Congratulations and welcome aboard! you will take the first step on an incredible journey.
    Access youth-enhancing products and opportunities and change your life in only a few minutes.</p>

<a style='color:rgb(0, 148, 167);  text-decoration: underline;' href='https://play.google.com/store/apps/details?id=com.akhnaton.networkselling.androidApp'>CLICK HERE to download the application</a>

<p style='color:rgb(0, 148, 167); '>Your user Name:</p>
<p style='color:rgb(0, 148, 167); ' >{{$data['email']}}</p>
<br>

<br>
<p style='color:rgb(0, 148, 167); '>Your Temporary Password:</p>

<p style='color:rgb(0, 148, 167);' >{{$data['password']}}</p>

<p style='color:rgb(0, 148, 167);' >Change your temporary password at any time in My Account Setting.</p>

<p style='color:rgb(0, 148, 167);' >Can we help?</p>


<p style='color:rgb(0, 148, 167);' >If you encounter an issue, please contact

    <a style='color:rgb(0, 148, 167);  text-decoration: underline;' href = 'mailto: info@nettinghub.com'>info@nettinghub.com</a>
</p>

</body>
</html>
