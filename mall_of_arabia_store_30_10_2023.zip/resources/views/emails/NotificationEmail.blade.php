
<html>
<head>
</head>
<body>
<img style='width:20%;' src='http://nettinghub.com/logo.png' alt='Italian Trulli'>

<h1 style='color:rgb(0, 148, 167);  text-align: center;'>{!! $data['title'] !!} </h1>


{!! $data['body'] !!}

</body>
</html>
