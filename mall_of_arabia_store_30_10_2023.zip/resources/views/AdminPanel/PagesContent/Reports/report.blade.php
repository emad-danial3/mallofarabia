@extends('AdminPanel.layouts.main')
@section('content')

    <meta name="csrf-token" content="{{ csrf_token() }}"/>
    <section class="content-header">
        <div class="container-fluid">
            <div class="row mb-2">
                <div class="col-sm-6">
                    <ol class="breadcrumb">
                        <li class="breadcrumb-item"><a href="{{route('adminDashboard')}}">Home</a></li>
                        <li class="breadcrumb-item"><a href="{{route('generalReports.report')}}">Reports</a></li>

                    </ol>
                </div>
                <div class="col-sm-6">

                </div>
            </div>
        </div><!-- /.container-fluid -->
    </section>

    <!-- Main content -->
    <section class="content">
        <div class="container-fluid">
            <div class="card">

                <div class="card-header">
                    <form class="form-inline row" method="get" action="{{url('admin/generalReports/report')}}">
                        <div class="form-group  mb-4 col-md-3">
                            <label for="date_from" class="text-right mr-2">Type</label>
                            <select name="type" class="form-control" required>
                                <option value="">Select Type</option>
                                <option value="order" @if(app('request')->input('type') == 'order')selected @endif>
                                    Order
                                </option>
                                <option value="user" @if(app('request')->input('type') == 'user')selected @endif>User
                                </option>
                            </select>

                        </div>
                        <div class="form-group  mb-2 col-md-3">
                            <label for="date_from" class="text-right mr-2">Date From </label>
                            <input type="date" id="date_from" name="date_from" @if(isset($date_from) && $date_from !='' ) value="{{$date_from}}" @endif class="form-control" placeholder="Date From" required>
                        </div>
                        <div class="form-group  mb-2 col-md-3">
                            <label for="date_to" class="text-right mr-2">Date To </label>
                            <input type="date" id="date_to" name="date_to" @if(isset($date_to) && $date_to !='' ) value="{{$date_to}}" @endif class="form-control" placeholder="Date To" required>
                        </div>

                        <button type="submit" class="btn btn-primary mb-2 col-md-2">Search</button>
                    </form>
<hr>
                    <div class="row">
                        <div class="col-md-9">

<div id="piechart" style="width: 900px; height: 500px;"></div>

                        </div>
                        <div class="col-md-3">
                            <table class="table table-striped">
                                <thead>
                                @if(app('request')->input('type') == 'order')
                                <tr>
                                    <th scope="col">Total Orders : {{$ordersSalesTotal}}</th>
                                    <input type="hidden" value="{{$ordersSalesTotal}}" id="ordersSalesTotal">
                                </tr>
                                <tr>
                                    <th scope="col">Sales Web  : {{$ordersSalesWeb}}</th>
                                    <input type="hidden" value="{{$ordersSalesWeb}}" id="ordersSalesWeb">
                                </tr>
                                <tr>
                                    <th scope="col">Sales Mobile : {{$ordersSalesmobile}}</th>
                                     <input type="hidden" value="{{$ordersSalesmobile}}" id="ordersSalesmobile">
                                </tr>
                                <tr>
                                    <th scope="col">Sales Bazar : {{$ordersSalesAdmin}}</th>
                                     <input type="hidden" value="{{$ordersSalesAdmin}}" id="ordersSalesAdmin">
                                </tr>
                                <tr>
                                    <th scope="col">Sales Bazar OnLine : {{$ordersSalesonLine}}</th>
                                     <input type="hidden" value="{{$ordersSalesonLine}}" id="ordersSalesonLine">
                                </tr>
                                @endif
                                @if(app('request')->input('type') == 'user')
                                    <tr>
                                        <th scope="col">Total Recruits Users : {{$usersCount}}</th>
                                    </tr>
                                @endif

                                </thead>
                            </table>
                        </div>
                    </div>
                </div>
            </div>


            <!-- /.row -->
        </div><!-- /.container-fluid -->


    </section>

   @push('scripts')

    <script type="text/javascript" src="https://www.gstatic.com/charts/loader.js"></script>
    <script type="text/javascript">
      google.charts.load('current', {'packages':['corechart']});
      google.charts.setOnLoadCallback(drawChart);

      function drawChart() {
        var Web=parseFloat($('#ordersSalesWeb').val());
        var Mobile=parseFloat($('#ordersSalesmobile').val());
        var Bazar=parseFloat($('#ordersSalesAdmin').val());
        var onLine=parseFloat($('#ordersSalesonLine').val());
        var data = google.visualization.arrayToDataTable([
          ['Task', 'Hours per Day'],
          ['Web',     Web],
          ['Mobile',      Mobile],
          ['Bazar',  Bazar],
          ['Bazar OnLine', onLine],
        ]);

        var options = {
          title: Web>0? 'My Total Sales':''
        };

        var chart = new google.visualization.PieChart(document.getElementById('piechart'));

        chart.draw(data, options);
      }
    </script>
  @endpush
@endsection
