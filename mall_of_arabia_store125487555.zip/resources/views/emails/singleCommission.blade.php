
<html>
<head>
</head>
<body>
<img style='width:20%;' src='http://nettinghub.com/logo2.png' alt='Italian Trulli'>

<h1 style='color:rgb(0, 148, 167);  text-align: center;'> Congratulation {{$data['full_name']}} </h1>


<h3 style='color:rgb(0, 148, 167);  text-align: center;'>Check your commission</h3>


<p style='text-align: center;font-size:16px;color:rgb(0, 148, 167);'>If you have any questions, contact us at <a style='color:rgb(0, 148, 167);'  href = 'mailto: info@nettinghub.com'> info@nettinghub.com</a></p>


<p style='text-align: center;font-size:10px;color:rgb(0, 148, 167);'>This message is from a notification-only address. Please do not reply to this email</p>




</body>
</html>
