
<html>
<head>
    <title>Commission mail</title>
</head>
<body>


<img style='width:20%;' src='http://nettinghub.com/logo2.png' alt='nettinghub'>

<h3 style='color:rgb(0, 148, 167)'>Congratulation {{$data['full_name']}}</h3>

<p style='color:rgb(0, 148, 167)'> {{$data['uname']}} now joining as a {{$data['acname']}} member on your Team!</p>

<p style='color:rgb(0, 148, 167)'> Check your commission</p>






<p style='color:rgb(0, 148, 167);' >Can we help?</p>


<p style='color:rgb(0, 148, 167);' >If you have any questions, contact us at


    <a style='color:rgb(0, 148, 167);  text-decoration: underline;' href = 'mailto: info@nettinghub.com'>info@nettinghub.com</a>


</p>



</body>
</html>
