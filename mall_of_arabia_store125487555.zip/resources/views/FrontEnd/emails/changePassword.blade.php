
<html>
<head>
</head>
<body>


<p style='text-align: center;color:rgb(0, 148, 167);'>Your New Password : <br>{{$data['password']}}</p>


<p style='text-align: center;font-size:10px;color:rgb(0, 148, 167);'>This message is from a notification-only address. Please do not reply to this email</p>

</body>
</html>
