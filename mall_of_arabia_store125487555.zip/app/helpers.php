<?php

if (!(function_exists('trimStringText')))
{
   function trimStringText($str)
    {
        return trim($str);
    }
}

?>





