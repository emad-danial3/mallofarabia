<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class AbstractModel extends  Model
{
    protected  $guarded=['id'];
}
