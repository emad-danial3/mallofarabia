<?php

namespace App\Constants;

class PaymentNames
{

    const   FAWRY_PAYMENT              = 'Fawry';
    const   OPAY_PAYMENT               = 'Opay';
    const   ORDER_HEADER_ID_SUB_STRING = 'orderNumber';
}
