<?php

namespace App\Http\Repositories;

interface PaymentLogRepository
{

}
