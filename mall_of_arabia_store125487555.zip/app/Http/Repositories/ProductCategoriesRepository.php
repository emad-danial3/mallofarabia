<?php

namespace App\Http\Repositories;

interface ProductCategoriesRepository
{

}
