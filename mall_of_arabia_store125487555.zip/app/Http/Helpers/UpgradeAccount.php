<?php

namespace App\Http\Helpers;

trait UpgradeAccount
{

}
